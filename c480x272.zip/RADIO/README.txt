Radio specific configuration files are stored in this directory.
