You can put firmware for your modules or radio in this folder.
Files in this folder are NOT automatically applied.
