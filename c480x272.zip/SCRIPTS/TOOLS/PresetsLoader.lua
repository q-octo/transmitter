-- TNS|Presets|TNE

local function run()
  return "/SCRIPTS/PRESETS/engine/main.lua"
end

return { run = run }
