You can put your model and other graphic files in this directory.
Supported formats include BMP and PNG (including PNG with transparency).
